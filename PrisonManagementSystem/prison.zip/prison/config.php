<?php
return [
	'client-key' => '6LdRdmkUAAAAAH565y_92tdR1_GRPOLxtQGmUM7i',
	'secret-key' => '6LdRdmkUAAAAADndaVam9OvyWdvrhh5vVpitZamq'
];
